package com.bubnov.exception;

public class DatabaseException extends Exception {
    public DatabaseException(String message) {
        super.getMessage();
    }

}
