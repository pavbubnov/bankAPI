package com.bubnov.exception;

public class RequestException extends Exception{
    public RequestException(String message) {
        super(message);
    }
}
